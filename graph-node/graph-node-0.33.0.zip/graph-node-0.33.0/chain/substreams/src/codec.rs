#[rustfmt::skip]
#[path = "protobuf/substreams.entity.v1.rs"]
mod pbsubstreamsentity;

pub use pbsubstreamsentity::*;
