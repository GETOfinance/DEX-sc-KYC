DROP FUNCTION remove_unassigned_deployment_indexes();
