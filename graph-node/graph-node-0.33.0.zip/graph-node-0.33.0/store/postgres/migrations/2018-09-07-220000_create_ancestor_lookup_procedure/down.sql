/**************************************************************
* DROP ANCESTOR LOOKUP FUNCTION
**************************************************************/
DROP FUNCTION lookup_ancestor_block(VARCHAR, BIGINT);
