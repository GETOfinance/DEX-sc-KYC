/**************************************************************
* DROP FUNCTIONS
**************************************************************/
DROP FUNCTION jsonb_diff_val(JSONB, JSONB);
DROP FUNCTION revert_row_event(INTEGER, INTEGER);
DROP FUNCTION revert_transaction(INTEGER);
DROP FUNCTION revert_transaction_group(INTEGER[]);
DROP FUNCTION revert_block(VARCHAR);
