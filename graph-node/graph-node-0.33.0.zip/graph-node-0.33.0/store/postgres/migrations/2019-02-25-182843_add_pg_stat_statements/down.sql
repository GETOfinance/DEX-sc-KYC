DROP EXTENSION IF EXISTS pg_stat_statements;
