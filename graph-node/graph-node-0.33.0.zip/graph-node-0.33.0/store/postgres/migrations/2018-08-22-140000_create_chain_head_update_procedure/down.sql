/**************************************************************
* DROP BLOCK INGESTOR FUNCTIONS
**************************************************************/

DROP FUNCTION attempt_chain_head_update(VARCHAR, BIGINT);
