/**************************************************************
* DROP TABLES
**************************************************************/
DROP TABLE ethereum_blocks;
DROP TABLE ethereum_networks;
