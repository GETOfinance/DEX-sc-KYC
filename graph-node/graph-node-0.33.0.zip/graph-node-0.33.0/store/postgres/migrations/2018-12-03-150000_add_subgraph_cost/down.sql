ALTER TABLE subgraph_deployments DROP COLUMN cost;
