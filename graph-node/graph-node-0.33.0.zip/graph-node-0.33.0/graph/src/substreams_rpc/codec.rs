#[rustfmt::skip]
#[path = "sf.substreams.rpc.v2.rs"]
mod pbsubstreamsrpc;

pub use pbsubstreamsrpc::*;
