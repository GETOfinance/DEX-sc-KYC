#[rustfmt::skip]
#[path = "sf.substreams.v1.rs"]
mod pbsubstreams;

pub use pbsubstreams::*;
