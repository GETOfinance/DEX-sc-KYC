///! Extension traits for external types.
pub mod futures;
