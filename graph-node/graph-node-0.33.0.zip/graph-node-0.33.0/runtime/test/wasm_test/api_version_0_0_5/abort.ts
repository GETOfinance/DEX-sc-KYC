export * from './common/global'

export function abort(): void {
  assert(false, "not true")
}
